CloudFormation nested stacks for ECS WebApp
